# Architettura

- `main.cpp`: inizializzazione Qt e QML.
- `Main.qml`: touchscreen e pagine del mixer, ora con `Window.FullScreen`.
- `mixercontroller.{h,cpp}`: modello dei canali, parametri DSP, comandi e stato esposti alla GUI.
- `audioengine.{h,cpp}`: backend ALSA, acquisizione, riproduzione e ciclo audio.
- `dsp.h`: elaborazione del segnale.
- `bcf2000.cpp`: mapping e feedback MIDI per il controller BCF2000.
- `dsp_test.cpp`, `fft_test.cpp`: test C++ eseguibili con CTest.

## Limiti di progetto

L'interfaccia rappresenta 8 channel strip, 4 AUX e uscite logiche. Questo **non** equivale a 8 ingressi e 8 uscite hardware: con UMC202HD sono disponibili 2 ingressi e 2 uscite fisiche. La mappatura MIDI estesa 0.6.39 non è stata verificata sull'hardware. Non è implementato un DCA o una pagina GROUP nella release presente. Le proposte discusse non vanno confuse con funzioni esistenti.

## Audio live

Non considerare questa versione pronta per utilizzo live critico: testare XRUN, latenza, feedback, mute, livelli, stabilità e recovery. Collegare amplificazione a volume basso durante le prove.
