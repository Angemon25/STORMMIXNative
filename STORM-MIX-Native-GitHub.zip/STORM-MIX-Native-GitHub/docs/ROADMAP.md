# Roadmap proposta (non implementata)

- Pagina DCA: fino a 8 gruppi di controllo, assegnazione canali, nomi, MUTE e fader virtuale; il livello originale dei singoli canali resta invariato e il guadagno DCA viene applicato nel DSP.
- Banco BCF2000 dedicato ai DCA, preferendo fader per i livelli e encoder per controlli contestuali.
- Eventuali veri GROUP bus con somma audio e processing dedicato: progetto separato dai DCA.
- Migliorare routing, FX, feedback MIDI, gestione dei banchi e test di latenza/stabilità.
- Eventuale supporto a interfacce multicanale; aggregazione di più UMC202HD richiederebbe compensazione clock e non è implementata.
