# Risoluzione problemi

## Nessun dispositivo audio
`arecord -l` e `aplay -l`; in SYSTEM scegliere gli endpoint ALSA corretti. Controllare eventuali conflitti con altri server audio.

## Nessun suono
Controllare livelli hardware, ingresso/uscita selezionati, mute, solo, master, direct monitor, routing e stato motore. Avviare a basso volume.

## Finestra non fullscreen
Il file `Main.qml` imposta `visibility: Window.FullScreen`. Verificare di eseguire il binario appena compilato e che il compositor Wayland consenta fullscreen.

## BCF2000 non risponde
Verificare modalità MIDI standard, preset, porta MIDI, permessi, corrispondenza CC e che non sia cambiato il preset hardware. Verificare con `aconnect -l`.

## Build fallita
Installare Qt6 Quick, QuickControls2, ALSA dev, CMake e toolchain C++17. Eseguire `cmake -S . -B build -DCMAKE_BUILD_TYPE=Release` e leggere il primo errore significativo.
