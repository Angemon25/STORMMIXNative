# STORM MIX Native v0.6.1 beta (Raspberry Pi 4)

## Cambiamenti
- SHOW: export/import di file `.conf` con QSettings IniFormat; reset con conferma. I dispositivi ALSA rimangono invariati durante import e reset. Percorso predefinito `~/storm_shows/`.
- EQ: spettro MAIN post-uscita reale sovrapposto alla curva EQ (FFT 1024 punti, circa 5 aggiornamenti/s); attenzione: e' una misura della somma L/R, non un analizzatore per ogni singolo canale. Sotto 50 Hz la risoluzione e' limitata.
- Dynamics: spettro MAIN separato dalla curva transfer, punto di livello e riduzione guadagno; aggiornamenti del drag limitati.
- MIXER: barre di riduzione guadagno discendenti accanto ai VU; MAIN mostra due barre distinte COMP e LIMIT.
- Routing fisico OUT1/OUT2: MAIN stereo, MAIN mono, AUX1..4 o mute. Non amplia il numero di uscite fisiche ALSA; AUX continuano a essere sommati al MAIN come nella 0.6.0.
- Migliorati allineamenti nomi strip, ridisegno Canvas meno frequente.

## Limiti e sicurezza
- Release beta: Qt6/QML non compilato in questo ambiente; compilazione e verifica runtime necessarie sul Raspberry.
- Il meter del limiter mostra la riduzione di picco del clipping finale, non un limiter lookahead professionale.
- La misura FFT e' approssimata, non calibrata, e non va usata come analizzatore di misura.
- Non utilizzare per eventi live finche' la stabilita' non e' verificata.

## Compilazione
```
cd ~
unzip -o storm_mix_native_v06_1_beta.zip
cd storm_mix_native_v06_1
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
ctest --test-dir build --output-on-failure
```

## Avvio
```
env -u DISPLAY XDG_RUNTIME_DIR=/run/user/1000 WAYLAND_DISPLAY=wayland-0 QT_QPA_PLATFORM=wayland ./build/storm-mix
```
