# STORM MIX Native 0.6.10 Beta
Targeted OUTPUT page layout fix for 1024x600 touchscreen.
- Three subviews: CROSSOVER + LEVEL / PARAMETRIC EQ / GATE COMP LIMIT.
- Output selection OUT1-8 remains visible above subview tabs.
- Full-width EQ and Dynamics plots rather than half-width panels.
- Taller crossover graph and more vertical space for slope selectors.
- Existing DSP engine, audio routing, FFT and show presets preserved.
- UI has not been compiled or visually verified on Raspberry Pi; test before live use.
