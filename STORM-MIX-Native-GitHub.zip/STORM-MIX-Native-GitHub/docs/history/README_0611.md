# STORM MIX Native 0.6.11 beta
- FFT visual weighting: five-bin Gaussian power averaging plus a fixed mild low-frequency tilt. No auto normalization, so EQ gain differences remain visible.
- CHANNEL analyzer selection explicitly follows selected channel changes while on CHANNEL page.
- LINK/UNLINK: snapshot right-channel independent fader/gain/mute/solo, restore on unlink, preserving original channel state.
- EQ changes still come from post-DSP audio, not a fake EQ-curve overlay. If spectrum remains unchanged, confirm live audio and EQ bypass/mute.
- Existing DSP/audio interface and OUTPUT page unchanged.
- Raspberry Pi Qt6/QML compile and runtime verification still required.
