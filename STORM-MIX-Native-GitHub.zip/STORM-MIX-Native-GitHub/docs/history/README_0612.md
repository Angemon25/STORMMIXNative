# v0.6.12 SAFE audio beta

- Bypass the defective gate stage on channels, AUX, MAIN and physical outputs. This is an emergency safety workaround; gate controls are temporarily inactive.
- Use a console-style piecewise fader taper with finer resolution near 0 dB; numerical fader values remain real dB.
- Compressor and limiter stages remain active; if pumping persists, investigate their envelopes and bypass them as needed.
- Verify at low volume on Raspberry; full Qt6 runtime testing not available in this environment.
