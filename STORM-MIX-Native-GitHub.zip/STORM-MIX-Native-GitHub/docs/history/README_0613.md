# STORM MIX Native v0.6.13 Beta
- Individual ON/BYPASS buttons for Gate, Compressor and Limiter on channels, AUX, MAIN and physical OUTPUT DSP.
- All three processors default to BYPASS; values are persisted in QSettings and SHOW presets.
- When enabling the gate, use a soft gate gain rather than the previous flawed instantaneous envelope division. Test at low volume.
- Stereo-linked channels share dynamics enabled status.
- OUTPUT hard peak ceiling is a separate protection clamp and remains active even if its Dynamics LIMIT is bypassed.
- ALSA and other DSP features retained. Raspberry Qt6/QML build/runtime must be tested.
