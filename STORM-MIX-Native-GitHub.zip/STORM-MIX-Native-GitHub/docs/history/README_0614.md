# STORM MIX 0.6.14 Beta

- FFT attack 0.95, release 0.68 per analyzer update, reducing visual inertia.
- Removed broad 5-bin spectral power averaging; now interpolates neighboring bins.
- Display smoothing limited to one band each side (sigma 0.7).
- Spectrum vertical range expanded for visually stronger peaks (~-62 to -8 dBFS after display lift; floor clipped).
- Existing post-EQ/post-Dynamics/post-fader channel tap unchanged; no synthetic EQ response is added to FFT.
- Added C++ regression test: 1 kHz tone +12 dB EQ must increase analyzer-tap RMS by >2.5x.
- If FFT still does not change, confirm spectrum source selection, audio input, EQ band activation and actual backend EQ state.
- Beta: Qt6 full build and actual Raspberry playback need verification.
