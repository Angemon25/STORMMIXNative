# STORM MIX Native v0.6.15 Beta
- FFT/RTA mode switch in the upper-left corner of every EQ graph, shared across channel/AUX/MAIN/OUTPUT.
- RTA is a real 30-band, 1/3-octave analysis of the same post-DSP measured FFT, not the EQ curve.
- Fix immediate ON/BYPASS button refresh by depending explicitly on parameterRevision, which emits parameterRevisionChanged from C++.
- Previous audio engine and DSP retained.
- Qt6/QML Raspberry Pi runtime verification required.
