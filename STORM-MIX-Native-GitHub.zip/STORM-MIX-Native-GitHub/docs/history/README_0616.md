# STORM MIX Native v0.6.16 Beta
- Two compact Y-axis controls at top-right of each EQ/analyzer graph.
- EQ ±24: cycles through ±12/18/24/36/48/60/72 dB. Scales plotted EQ response and drag coordinates, while EQ band gain remains capped at its DSP-supported ±18 dB.
- RTA 60: cycles through 30/45/60/90/120 dB display range (0 to negative floor), shared by FFT and RTA; does not change audio gain.
- Both controls update Canvas immediately, globally across EQ pages.
- FFT/RTA switch remains top-left.
- Build/runtime on Raspberry Pi still requires testing.
