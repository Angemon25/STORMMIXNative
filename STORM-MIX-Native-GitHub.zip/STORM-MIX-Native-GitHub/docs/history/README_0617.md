# STORM MIX v0.6.17 beta
- Spectrum graph explicitly repaints on C++ spectrumChanged; Canvas reads mixer.spectrum at render time rather than relying solely on QVariantList binding propagation.
- FFT log-band measurement uses maximum power across actual FFT bins in each frequency band; this better exposes narrow peaks and EQ changes.
- POST DSP measured dBFS diagnostic readout at selected EQ band's center frequency (NOT a simulated EQ response).
- EQ/Dynamics, FFT/RTA switch and scales preserved.
- Raspberry Qt6/QML build and hardware verification still required.
