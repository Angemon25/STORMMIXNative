# STORM MIX Native 0.6.18 Beta
- Spectrum update 20Hz (50ms) instead of 10Hz (100ms).
- Instant display attack and fast 12dB/frame release; no smoothing across frequency bins.
- Independent 350ms peak hold with 30dB/s decay, shown as golden line (FFT) and white caps (RTA).
- Peak hold uses actual post-DSP FFT data; not a simulated EQ curve.
- Performance depends on Pi 4 CPU; if UI lags revert refresh to 100ms.
- Qt6/QML and ALSA hardware validation required on Pi.
