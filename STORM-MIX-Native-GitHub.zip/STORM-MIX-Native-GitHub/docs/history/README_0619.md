# STORM MIX Native v0.6.19 Beta
- Replaced overlapping low-frequency FFT max-bin sampling with narrow interpolated Hann-bin power weighting at each true logarithmic frequency. 20 and 50 Hz no longer automatically share the same max bin.
- Display-only musical +3 dB/octave tilt relative to 1 kHz, capped. No A-weighting (would suppress bass).
- RTA now aggregates power over each fractional-octave group instead of selecting only the highest point. NOTE: this is an approximation from the existing 192 log-frequency display bins, not a calibrated IEC fractional-octave RTA.
- EQ points now render immediately while dragging, with DSP updates every 25ms rather than a continuously restarted debounce. Response redraw timer shortened to 30ms; reduced curve paint samples.
- No changes to audio DSP processing.
- Needs full Qt6 build and touch interaction test on Raspberry Pi.
