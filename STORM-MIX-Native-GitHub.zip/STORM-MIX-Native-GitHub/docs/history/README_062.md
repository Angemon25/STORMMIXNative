# STORM MIX 0.6.2 Beta – UI responsiveness
- Vertical faders commit to backend while dragging (55 ms throttle); numeric display follows pointer.
- Master value display follows live drag position.
- Channel titles reserve 16 px above text to avoid collision with color strip.
- Spectrum FFT reduced from 5 Hz to ~3.3 Hz; spectrum canvas uses half the drawing points.
- EQ/Dynamics redraw coalesced to 100 ms; EQ curve sampling every 8 pixels.
- ALSA/DSP signal processing left unchanged.
This is a targeted experimental UI update. Qt/QML compilation must be verified on Raspberry Pi.
