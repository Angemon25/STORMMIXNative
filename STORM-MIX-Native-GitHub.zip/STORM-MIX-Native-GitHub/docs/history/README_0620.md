# STORM MIX v0.6.20 beta
- RTA: 30 one-third-octave band powers integrated from the original FFT bins, Hann ENBW correction, not re-binned 192-point display spectrum.
- FFT: interpolate raw linear power, remove arbitrary 3dB/oct display tilt, preserve fast attack and peak hold.
- EQ dragging: reduce response-plot sampling density, immediate repaint and 50ms DSP commit interval.
- The 8192 FFT has ~5.9Hz resolution at 48kHz; low-frequency bands remain inherently coarse. Longer/multiresolution FFT needed for accurate sub-bass measurements.
- Qt6/Raspberry Pi runtime validation pending.
