# v0.6.21 Beta
- RTA increased from 30 third-octave bands to 60 sixth-octave bands.
- FFT power is integrated with fractional edge-bin overlap. No simulated equalizer response is added.
- POST DSP diagnostic now explicitly depends on spectrum + EQ revision, and shows selected EQ gain alongside measured spectral level. These are *different* quantities.
- Note: post-DSP dBFS level cannot be expected to follow EQ gain if there is no steady input energy at the selected frequency. The user should test with a stable sine or pink noise.
- 8192-point FFT at 48kHz resolves ~5.86 Hz; low-frequency sixth-octave bands are estimates and are not IEC-calibrated.
