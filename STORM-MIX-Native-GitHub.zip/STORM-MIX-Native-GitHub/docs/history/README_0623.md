# STORM MIX Native v0.6.23 Beta
- Reduce misleading LF motion in FFT and RTA when only high frequencies are present.
- Low-frequency spectral floor suppression (<90 Hz), using a measured relative floor (strongest FFT component minus 52 dB) and an absolute -70 dBFS floor.
- Below the floor, bins are displayed at -90 dBFS. The floor transitions to the original display above 90 Hz.
- This is a VISUAL noise gate and does not alter the audio DSP. Weak real bass can be hidden; do not treat this as a calibrated LF measurement.
- Still 8192-sample Hann FFT, 60 RTA bands; future accurate LF analysis requires longer window and test tones.
