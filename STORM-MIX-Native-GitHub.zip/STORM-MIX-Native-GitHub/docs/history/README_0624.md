# STORM MIX Native v0.6.24 Beta
A pure 60 Hz tone produced broadband spikes on the FFT display. The analyzer ring was copied while the audio thread could overwrite the buffer, causing discontinuities. This release retries the nonblocking snapshot when the write pointer moves. Also removes the LF display gate introduced in 0.6.23.
This mitigates but does not mathematically guarantee a coherent snapshot when all retries fail; further diagnostic verification with real 60 Hz signal on the Pi is required.
