# STORM MIX Native v0.6.25 Beta

- Replaces mutable atomic ring with 3 immutable, 8192-frame snapshots. Audio thread assembles contiguous PCM windows and publishes only completed windows. Reader marks slot as in use during copying; producer never blocks.
- FFT consumes only new completed windows. New diagnostic PEAK Hz and dBFS displayed next to POST DSP.
- No spectral noise gates or frequency weighting.
- Windows cover 170.7 ms at 48 kHz; expect ~5.86 new windows/s, not 20 unique FFT updates/s.
- Needs Qt6 Raspberry Pi compilation and hardware validation.
