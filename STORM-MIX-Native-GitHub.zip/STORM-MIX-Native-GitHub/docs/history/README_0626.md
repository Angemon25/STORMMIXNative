# 0.6.26 beta
FFT moved from Qt GUI timer to a separate worker thread (65ms polling). Hann window precalculated once. GUI receives precomputed spectral power via queued invocation and renders on the main thread. Audio callback remains nonblocking. Previous coherent 8192-frame capture retained.
Diagnostic: PEAK frequency and dBFS on EQ page. If PEAK at 60 Hz while plot peaks at high frequencies, issue is visual; otherwise inspect audio analyzer samples.
Not verified on Raspberry Pi or Qt6 build environment.
