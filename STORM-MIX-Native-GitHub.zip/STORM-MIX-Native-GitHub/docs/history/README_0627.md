# STORM MIX v0.6.27 beta
- Native S32_LE ALSA capture and playback (independently negotiated, with S16_LE fallback).
- Correct 32-bit PCM to floating-point conversion (divisor 2147483648.0).
- Dedicated isolated FFT regression test for 60 Hz, 1 kHz and 10 kHz.
- Existing analyzer and GUI preserved. Not tested on actual Raspberry Pi/UMC202HD.

- FIX CONFIRMED: FFT bit reversal missed final `j ^= bit`, causing synthetic 60 Hz input to show 16500 Hz. Synthetic 60/1000/10000 Hz regression tests pass after fix.
