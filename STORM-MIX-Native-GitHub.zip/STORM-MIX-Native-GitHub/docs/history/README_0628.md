# STORM MIX v0.6.28 beta — UI performance
- Retains corrected FFT bit reversal from v0.6.27.
- Limits queued FFT GUI updates to one at a time, preventing backlog when UI is busy.
- Reduces worker polling frequency to 90 ms (roughly 11 Hz).
- Coalesces QML spectrum Canvas redraw requests (85 ms debounce), avoiding duplicate paints.
- Leaves ALSA/DSP audio processing and meter refresh unchanged.
- Not tested on Raspberry Pi; compare responsiveness and audio xrun counts with v0.6.27.
