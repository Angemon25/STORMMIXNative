# STORM MIX v0.6.29 beta — fluid FFT/RTA and right dBFS scale
- Overlapping FFT windows (8192 samples, 2048 hop, 75% overlap) to update ~23.4 times/s at 48 kHz while preserving ~5.86 Hz frequency-bin resolution.
- Fixed 33 ms Canvas refresh timer with dirty flag. Fixes v0.6.28 debounce starvation; does not render more often than needed.
- Worker polls at 25 ms and sends at most one queued GUI update.
- FFT and RTA use same smoothed dBFS scale; orange right axis is 0 down to -range dBFS. EQ gain scale on left remains independent.
- RTA displays computed 1/6-octave band power referenced to digital full scale, not calibrated dB SPL; do not confuse with SPL measurement.
- Audio DSP, FFT bit reversal fix, and ALSA conversion unchanged.
- Requires Raspberry Pi / Qt6 verification; no claims of hardware performance made.
