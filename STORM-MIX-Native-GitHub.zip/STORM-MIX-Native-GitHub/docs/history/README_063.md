# STORM MIX Native 0.6.3 Beta

- Real 2048-sample Hann FFT, 96 logarithmic bands at 10 Hz.
- Per-band attack/release smoothing in C++ and interpolated Canvas spectrum.
- EQ x-axis uses 20 Hz–20 kHz logarithmic mapping with labelled Hz/kHz ticks.
- Compressor plot now fills the active reduction area up to the measured input level.
- Live compressor indicator and input level remain visible.
- ALSA device selection, DSP filters and routing are unchanged.

Requires compilation and functional verification on Raspberry Pi. The FFT measures MAIN post output, not individual input channels.
