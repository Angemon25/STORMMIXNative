# STORM MIX v0.6.30 beta
EQ drag responsiveness: capped redraw at 30 fps, throttled QSettings/DSP commits to 125ms while dragging with final commit on release, cached EQ biquad coefficients per plot render. FFT/RTA update path unchanged. Raspberry Qt runtime validation pending.
