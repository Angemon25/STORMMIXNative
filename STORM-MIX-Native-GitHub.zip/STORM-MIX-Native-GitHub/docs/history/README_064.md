# v0.6.4 Beta
- FFT 4096 samples: improved low-frequency resolution (11.7 Hz bin at 48 kHz), log display retained.
- Removed spectrum overlay from Dynamics/limiter graph; animated level indicator remains.
- Added explicit reset buttons to parameter sliders and mixer faders.
- Added numeric dBFS readings for channel and master meters.
- PFL: exclusive selection of a single channel or AUX; MAIN meter visually displays the selected channel's post-fader meter. **PFL does not change audio routing or create a dedicated headphone bus**.
- Added MAIN L and MAIN R independent selections to physical OUT1/OUT2 (existing indices retained).
- Refined OUTPUT/FX headings and contextual labels.
- ALSA hardware I/O remains 2x2. Experimental beta: compile and verify on Raspberry.
