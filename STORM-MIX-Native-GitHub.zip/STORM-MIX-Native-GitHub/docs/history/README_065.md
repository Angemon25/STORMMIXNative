# STORM MIX 0.6.5 Beta
- Analyzer tap is now selected channel post-EQ/dynamics/fader/mute; AUX post-bus; MAIN post-master; physical output post-filter/limiter.
- 8192-point FFT improves frequency-bin spacing to 5.86 Hz at 48 kHz; source changes clear stale samples.
- OUTPUT page scrollable: crossover curve, 12/24 dB/oct Butterworth HP/LP, trim, delay, ceiling, 8-band EQ and gate/comp/limit.
- AUX-routed output bypasses its additional EQ/dynamics to honor AUX DSP priority; output trim, crossover, delay, ceiling remain active.
- Only OUT1/OUT2 are physical on the 2x2 ALSA engine. OUT3..8 are editable presets but not audible.
- WARNING: experimental beta; full Qt/QML build unavailable in authoring environment. Run DSP tests and test at low monitor volume.
