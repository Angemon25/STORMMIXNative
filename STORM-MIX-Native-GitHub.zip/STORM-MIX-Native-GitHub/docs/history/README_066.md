# STORM MIX 0.6.6 Beta
Based on 0.6.5 with gain-ramping added to the DSP processing path.
- Channel input gain, channel fader, AUX fader, MAIN fader, and physical output trim use sample-by-sample ~15 ms one-pole smoothing.
- Target gain updates do not reset the smoothing state on configure().
- Preserves 0.6.5 channel-specific post-strip 8192 FFT and OUTPUT DSP/crossover page.
- EQ and crossover coefficient changes are still instantaneous: future work should interpolate coefficients or crossfade filters to avoid artifacts during rapid frequency/Q sweeps.
- Physical outputs remain 2 channels on current ALSA 2x2 device.
- Experimental; validate with tests and low volume.
