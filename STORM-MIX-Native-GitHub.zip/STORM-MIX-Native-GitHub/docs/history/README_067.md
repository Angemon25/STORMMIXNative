# STORM MIX 0.6.7 Beta
- Crossover graph uses one consistent logarithmic 20 Hz–20 kHz coordinate mapping for grid, labels and response. Labels are painted at tick positions, not in an evenly spaced Row.
- Output page is vertically more compact; all advanced DSP remains available by scrolling.
- Channel spectrum display uses 192 log-frequency display bands, linear-power interpolation between actual FFT bins, and Catmull–Rom curve rendering.
- FFT window stays 8192 samples. This improves visual continuity, **not** physical spectral resolution (about 5.86 Hz per bin at 48 kHz).
- Selected post-strip audio analyzer and DSP are inherited from 0.6.6.
- Qt/QML compile and visual validation still required on Raspberry Pi.
