# STORM MIX 0.6.8 Beta — readable EQ graph
- Logarithmic 20 Hz–20 kHz axis shared by EQ handles, FFT overlay, and frequency ruler.
- High contrast major frequency labels and dB guide; spectrum is gray behind cyan EQ response.
- Antialiased FFT path, interpolated per 1.5 screen pixels and softly filled, EQ response drawn at 3 px spacing.
- 8192-point FFT and post-strip channel selection remain from 0.6.7. This is a visual improvement, not new FFT resolution.
- DSP audio pipeline unchanged. Qt6/QML compilation must be checked on Pi.
