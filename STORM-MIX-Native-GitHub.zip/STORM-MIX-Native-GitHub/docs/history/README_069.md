# STORM MIX Native v0.6.9 Beta
- FFT: log-frequency Gaussian smoothing (sigma 1.55 / 192 bands), slightly faster attack and 8 dB fixed display lift.
- No peak auto-normalization: real EQ gain changes should remain visible.
- FFT tap remains actual post-EQ/post-Dynamics/post-fader/mute channel DSP output (and bus/output taps as previously implemented).
- OUTPUT page: crossover + output control on one row; output EQ + Dynamics on a second row; optimized for 1024x600 but scroll may still be needed.
- This changes spectrum presentation only; EQ coefficients and audio routing unchanged.
- Important: if CH2 FFT does not change when changing EQ, verify actual source signal, gain and non-zero EQ gain. A flat or muted input must show floor, not a fabricated response.
- Experimental. Verify Qt6/QML build and audio on Raspberry.
