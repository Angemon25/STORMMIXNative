# STORM MIX v0.6.31 — BCF2000 MIDI Standard Preset 1

**Experimental beta: motor feedback enabled.** Use preset 1 "Reason Mixer 1" and BCF2000 USB mode U-3. ALSA auto-connects to BCF2000 MIDI port 0. Motor faders may move at connection and bank switches. Keep hands clear. To disable motor feedback for testing, temporarily comment out `bcfFeedback();` in `bcf2000.cpp`.

Strip 1 is RESERVED and ignored in all banks (including its fader, encoder and buttons). MIDI physical strips 2-8:

* Bank 1: CH1-7 (faders volume, encoders PAN, top CC row MUTE, next CC row SOLO, third CC row SELECT).
* Bank 2: CH8, AUX1-4, MAIN, SELECTED CH (the last strip is the currently selected channel). MAIN is on physical strip 7. MAIN and AUX have no PAN.
* Bank 3: CH1-7, faders volume and encoders AUX1 sends; buttons MUTE/SOLO/SELECT.

Bottom buttons 49 and 50 (MIDI channel 4, CC 3 and CC 1) move to previous/next bank; see the .bcf preset file for their physical placement. On bank switch, all faders and encoder LED values are refreshed. BCF faders/encoders and MUTE/SOLO LEDs receive bidirectional MIDI CC feedback. MIDI output throttled to 8 messages/20 ms. No MIDI work in real-time audio callback. `midiStatus` and `midiBank` QML properties available.

**Important:** Fader dB-to-MIDI taper is currently an approximation (-60 to 0 to +10 dB); can be refined after physical testing. BCF button toggle logic uses inverted 127->0 from the backup. Since button state in BCF is locally toggled, MIDI feedback might interact with its internal state; test slowly. No automatic motor-touch suppression in this beta. The first strip is deliberately excluded even during feedback.

Build on Pi:
```
sudo apt install -y libasound2-dev qt6-base-dev qt6-declarative-dev
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
ctest --test-dir build --output-on-failure
```
