# v0.6.32 — BCF2000 hotfix
- Accept physical bank keys detected in log: MIDI ch 4 CC4 (previous), CC2 (next), plus CC3/CC1 as backup variants.
- Recognize bottom-row CC2-8 for bank-relative channel selection.
- MIDI polling is nonblocking, 50ms, max 16 incoming events per tick.
- Feedback limited to 2 changed messages per 50ms; input fader/encoder positions cached to prevent immediate feedback echo.
- Avoid redundant audio/UI updates for unchanged fader, pan, mute and solo values.
- Strip 1 remains reserved; no feedback is sent to its motor.
- Feedback still enabled; motor movements can occur when banks change. Keep hands clear.
- No changes to audio DSP or FFT.
- This build is not hardware-tested. The preset buttons 33-48 use CC1-16, while CC39-68 are other rows.
