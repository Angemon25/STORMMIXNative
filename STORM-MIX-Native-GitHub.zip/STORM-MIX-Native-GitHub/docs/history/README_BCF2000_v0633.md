# STORM MIX 0.6.33 — BCF2000 RX hotfix

Root cause in 0.6.32: `snd_seq_event_input_pending(seq,0)` checked only the local ALSA queue without fetching incoming USB MIDI events. Changed to `snd_seq_event_input_pending(seq,1)` to fetch pending events. Polls 32 input events at 20 ms intervals.

The BCF2000 ALSA client 32:0 was already connected to STORM MIX. ALSA direct events (`snd_seq_event_output_direct`) are sent to 32:0 without needing a reverse subscription in `aconnect -l`.

Feedback is rate-limited to 1 MIDI event per 20 ms and only sent on changes. The first full snapshot takes approximately 560 ms. No change to audio DSP. Strip 1 remains reserved. Bank controls MIDI ch 4 CC4 and CC2 (press=127).

This build is not verified on Raspberry hardware. If the GUI still lags, disable feedback temporarily in `pollBcf()` by commenting out `bcfFeedback();` to isolate output traffic.
