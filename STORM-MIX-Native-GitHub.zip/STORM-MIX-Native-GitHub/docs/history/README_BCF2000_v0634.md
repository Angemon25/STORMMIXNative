# v0.6.34 BCF2000 hotfix

Verified physical strip 2 buttons from user aseqdump:
- top: MIDI channel 1 (zero based 0), CC 2, 127 press/0 release
- bottom: MIDI channel 1, CC 10, 127 press/0 release

Strips 2-8 map CC 2-8 to MUTE and CC 10-16 to SOLO, acting on bank targets. Strip 1 stays reserved. MIDI feedback uses those same CC numbers, and now attempts explicit ALSA output subscription (`aconnect -l` should show `STORM MIX -> BCF2000`). MIDI output errors are printed in terminal. Fader and encoder mapping unchanged.

IMPORTANT: USB BCF2000 may need a different MIDI input port or BCF preset option to accept external motor/LED CC messages. Test motor feedback with hands clear, master low. This patch does not claim hardware feedback verified.
