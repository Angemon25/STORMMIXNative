# STORM MIX v0.6.35 – diagnostica BCF2000

Versione diagnostica basata sulla v0.6.34. Non cambia le mappature o la logica dei fader.

Avviare dal terminale e premere MUTE e SOLO della strip 2. Cercare:
- `[BCF INPUT BUTTON]` (messaggio ricevuto da ALSA)
- `[BCF ACTION]` (comando applicato al mixer)
- `[BCF OUTPUT]` (primi 36 messaggi di feedback trasmessi, con codice di risultato)
- `BCF2000: MIDI output subscription OK/FAILED`

In caso di feedback assente, `aconnect -l` mostra se l'uscita è sottoscritta. Il risultato >=0 di ALSA conferma l'accettazione della chiamata, non il movimento fisico del motore.
