# STORM MIX 0.6.36 — feedback latency optimization
- Feedback scans 28 cached slots each tick and sends up to 3 changed CC messages per tick, rather than scanning only 1 slot/tick (up to 560 ms delay).
- MIDI polling 30 ms instead of 20 ms to reduce Qt main-thread wakeups; physical fader/encoder/button mappings unchanged.
- Initial sync takes several ticks, changes normally update on the next tick.
- Keeps MIDI output debug limited to first 8 messages.
- Actual Raspberry Pi/BCF2000 performance not yet verified.
