# STORM MIX 0.6.37 beta

- The physical BCF2000 bank is shown persistently in the top header, with bank number and mapped controls.
- On a physical bank change the touchscreen switches to MIXER (bank 1), AUX (bank 2), or ROUTING (bank 3).
- MIDI input, fader, button mapping and motor feedback algorithm preserved from 0.6.36.
- Removed per-button incoming diagnostic logging to reduce console I/O.
- Further performance changes deliberately deferred until profiling on the Raspberry.
