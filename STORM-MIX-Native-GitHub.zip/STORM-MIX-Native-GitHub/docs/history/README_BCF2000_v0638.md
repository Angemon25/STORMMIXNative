# v0.6.38 BCF2000 SOLO hold-to-unity
- Hold a physical SOLO button for 2 seconds in any BCF bank to reset its mapped fader to 0.0 dB.
- Short SOLO press (release before 2 seconds) retains the existing SOLO toggle action.
- MUTE unchanged.
- In bank 2 MAIN fader also resets to 0 dB via its SOLO button; short press on MAIN does nothing, as before.
- Target captured when button is pressed; feedback automatically moves the fader to unity.
- Mixer channel and AUX faders already default to 0 dB on a fresh configuration. Existing saved settings are preserved.
- All other MIDI mappings unchanged.
