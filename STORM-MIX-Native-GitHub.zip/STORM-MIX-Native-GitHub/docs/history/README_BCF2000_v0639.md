# STORM MIX Native 0.6.39 — BCF2000 extended banks

BCF banks 1–3 retained. Added 4–18: AUX2/3/4 sends, selected-channel EQ gain/frequency/Q (bands 1–7), gate/comp/limiter (threshold, ratio, attack, release), MAIN EQ, AUX EQ, bus dynamics, FX, output DSP, routing.

DSP banks: fader and encoder 2–8 control the same parameter (7 parameters max); top buttons select CH1–7, AUX1–4, bus/dynamics target or output; lower buttons toggle dynamics where applicable. Long-press SOLO 0dB reset only applies to level banks. Strip1 reserved. Bank changes show current bank on touchscreen and switch to relevant page. MIDI feedback mirrors DSP values to motors/encoder rings.

Caveats: selected-channel EQ uses 7 of 8 EQ bands; remaining band accessible via touchscreen. Routing maps first seven outputs only; selected FX controls first seven of nine parameters. Other detailed parameters remain accessible via touchscreen. Bank controls require the same existing MIDI preset. This release is not hardware-validated.
