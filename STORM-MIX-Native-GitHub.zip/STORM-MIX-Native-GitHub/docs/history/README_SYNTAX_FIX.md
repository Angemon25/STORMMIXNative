STORM MIX v0.6.0 beta — QML syntax fix

Fixed 16 invalid QML property bindings that used a JavaScript statement block and return. Replaced with valid comma-expression bindings preserving parameterRevision dependency. DSP and ALSA unchanged. Full Qt build must be verified on Raspberry Pi.
