# STORM MIX Native 0.6.0-beta — Raspberry Pi 4

## Nuove funzioni
- Grafico EQ 8 bande parametrico, frequenza/gain trascinabili, Q con rotella e slider.
- Grafico Dynamics (gate/compressor/limiter) con threshold e ratio regolabili.
- DSP EQ/dynamics separato per i quattro bus AUX e per il MAIN stereo.
- Meter reali AUX, MAIN, riduzione guadagno di compressore/limiter e ceiling dell'output.
- Stereo link per coppie CH1/2, 3/4, 5/6, 7/8 (fader, gain, mute, solo, PFL, EQ, dynamics, sends; pan separato).
- Doppio clic reset fader e slider; pagina Meter Bridge compatta; master VU nella pagina mixer.
- AUX DSP raggiungibile dal pulsante di ogni strip AUX.

## Limiti e note di sicurezza
- **Versione beta non validata su Raspberry Pi:** compilare e testare prima di usare.
- ALSA rimane **2 ingressi / 2 uscite**. I canali 3-8 non hanno ingresso fisico; i quattro AUX hanno DSP e meter veri ma sono ripiegati nel MAIN, **non sono uscite fisiche indipendenti**.
- Il limiter finale resta un hard ceiling, **non** un limiter lookahead professionale; il relativo meter indica la riduzione istantanea introdotta dal ceiling.
- Il grafico dynamics rappresenta la curva statica ideale, mentre il DSP usa envelope con attack/release; la curva non rappresenta ogni transitorio.
- Salvare una copia della versione stabile 0.5.9/0.5.10 prima del test. Non utilizzare per diffusori senza protezioni hardware.

## Installazione da PC Windows
```powershell
scp .\\storm_mix_native_v06_0_beta.zip mixerpi@IP_RASPBERRY:~/
```

## Raspberry SSH
```bash
cd ~
unzip -o storm_mix_native_v06_0_beta.zip
cd storm_mix_native_v06_0
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
ctest --test-dir build --output-on-failure
```

## Avvio grafico locale via SSH
```bash
env -u DISPLAY XDG_RUNTIME_DIR=/run/user/1000 WAYLAND_DISPLAY=wayland-0 QT_QPA_PLATFORM=wayland ./build/storm-mix
```
